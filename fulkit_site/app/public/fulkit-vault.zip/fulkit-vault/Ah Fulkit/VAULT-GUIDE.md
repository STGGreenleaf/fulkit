# Your Fulkit Vault

This is your second brain. Everything between these folders is yours.

## Folder Structure

| Folder | What goes here |
|--------|---------------|
| `_FULKIT/` | Your brain. Files here are **always** loaded into every conversation. |
| `00-INBOX/` | Drop anything here. Fulkit sorts it for you. |
| `01-PERSONAL/` | About you — goals, people, habits. |
| `02-BUSINESS/` | Work, clients, strategy, finances. |
| `03-PROJECTS/` | Active projects and campaigns. |
| `04-DEV/` | Code context, architecture, decisions. |
| `05-IDEAS/` | Raw sparks, brainstorms, what-ifs. |
| `06-LEARNING/` | Books, courses, research notes. |
| `07-ARCHIVE/` | Done but worth keeping. |

## Important

**Do not rename these folders.** Fulkit uses the folder names to auto-file your notes. Rename them and the filing breaks. Add whatever you want *inside* them — subfolders, files, anything. The structure is the skeleton. Your content is the muscle.
