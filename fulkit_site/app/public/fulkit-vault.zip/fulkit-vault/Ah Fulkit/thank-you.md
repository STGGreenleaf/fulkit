# Welcome to Fulkit

Thanks for being here.

This vault is yours. Plain markdown files you can open anywhere, move anywhere, read with any app. We never see it unless you show it to us.

Everything you save, capture, or create lives between these folders. Fulkit reads them, learns from them, and files new stuff back in — but you hold every key.

Let's get to work.

— Collin
