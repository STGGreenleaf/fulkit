# Inbox
Drop anything here. Fülkit sorts it for you.
